# RestedXP Guides

## [v4.9.19-15-gc2df7ea](https://github.com/RestedXP/RXPGuides/tree/c2df7eac0f3836e2162223deb7407c9a7b6c99bc) (2026-02-04)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.9.19...c2df7eac0f3836e2162223deb7407c9a7b6c99bc) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- Update zhCN TBC starter guides from Pontoon  
- Update zhCN addon locale from Pontoon  
- Update zhCN TBC starter guides from Pontoon  
- Add Midnight Group vor 1-80  
- typo fixes  
- Darkshore tbc improvements  
- Update to latest Tactics' TBC statWeights  
- Update zhCN TBC starter guides from Pontoon  
- Update zhCN TBC starter guides from Pontoon  
- Fix disabled SP dungeon icon  
- Convert custom dungeon icons to in-game  
- Tides' Hollow typo fix  
- Fix TBC dungeonList  
- Update zhCN TBC starter guides from Pontoon  
- Update zhCN TBC starter guides from Pontoon  
